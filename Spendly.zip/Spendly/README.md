# Spendly: Android expense tracker

Log what you spend (in Rupiah), see this month's total, and a breakdown by category. Data is saved on your phone.

## Build the APK

1. Install **Android Studio** (free): https://developer.android.com/studio
2. Unzip this project, then in Android Studio choose **File > Open** and select the `Spendly` folder.
3. Wait for "Gradle sync" to finish (first time takes a few minutes and needs internet). If it asks to upgrade versions, you can accept.
4. To get an APK file: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Click "locate" when it finishes.
   The file is at `app/build/outputs/apk/debug/app-debug.apk`.
5. Copy the APK to your phone and open it. Allow "install unknown apps" if Android asks.

## Run directly on your phone (alternative)

1. On the phone: Settings > About phone > tap **Build number** 7 times, then enable **USB debugging** in Developer options.
2. Plug the phone into your computer and press the green **Run** button in Android Studio.

## Files

- `app/src/main/java/com/example/spendly/MainActivity.kt`: all app code (screen, add dialog, storage)
- `app/build.gradle.kts`: dependencies and Android settings
- `app/src/main/AndroidManifest.xml`: app declaration
